"""Lotes reanudables. Estado local sin credenciales; servicios remotos inyectados."""
from collections import Counter
from contextlib import contextmanager
from datetime import datetime, timezone
from functools import partial
from pathlib import Path
import csv
import hashlib
import io
import json
import os
import subprocess
import tempfile

from convertir_nota import programa, ruta_pdf
from normalizar_latex import preparar_boveda

BASE = Path(__file__).resolve().parent


class BovedaModificada(RuntimeError):
    pass


def sha_archivo(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def escribir_atomico(path, text):
    path = Path(path)
    temp = None
    try:
        with tempfile.NamedTemporaryFile(mode="w", encoding="utf-8", newline="", dir=path.parent,
                                         prefix=path.name + ".", delete=False) as f:
            temp = Path(f.name)
            f.write(text)
            f.flush()
            os.fsync(f.fileno())
        os.replace(temp, path)
    finally:
        # En Windows hay que cerrar el archivo antes de eliminarlo.
        if temp is not None:
            temp.unlink(missing_ok=True)


@contextmanager
def bloqueo(output):
    # Bloqueo del sistema operativo: se libera incluso si termina el proceso.
    path = Path(output) / ".migracion.lock"
    with path.open("a+b") as f:
        f.seek(0, 2)
        if f.tell() == 0:
            f.write(b"0"); f.flush()
        f.seek(0)
        try:
            if os.name == "nt":
                import msvcrt
                msvcrt.locking(f.fileno(), msvcrt.LK_NBLCK, 1)
            else:
                import fcntl
                fcntl.flock(f.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError as error:
            raise RuntimeError("Ya hay otra migracion usando esta carpeta de salida. Espera o deten la otra ejecucion.") from error
        try:
            yield
        finally:
            f.seek(0)
            if os.name == "nt":
                msvcrt.locking(f.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                fcntl.flock(f.fileno(), fcntl.LOCK_UN)


def huella_lote(config, inventario, versiones=None):
    if versiones is None:
        versiones = {}
        for name in (config.exporter, "pandoc", "xelatex"):
            r = subprocess.run([programa(name), "--version"], capture_output=True, timeout=30, check=True)
            versiones[name] = r.stdout.decode("utf-8", errors="replace")
    codigo = {name: sha_archivo(BASE / name) for name in (
        "normalizar_latex.py", "convertir_nota.py", "migrar_obsidian.py", "lote_obsidian.py",
        "callouts.lua", "estilos.tex",
    )}
    # Conservador: incluye TODA la boveda para cubrir notas incrustadas y adjuntos
    # sin adivinar dependencias. Si cambia algo, se invalida el cache del lote.
    data = {"archivos": {k: v["sha256"] for k, v in inventario.items()}, "codigo": codigo,
            "versiones": versiones, "proyecto": config.url, "vault": str(config.vault),
            "salida": str(config.output)}
    return hashlib.sha256(json.dumps(data, sort_keys=True, ensure_ascii=False).encode()).hexdigest()


def validar_inventario(vault, inventario):
    for rel, expected in inventario.items():
        path = vault / rel
        try:
            stat = path.stat()
        except OSError as error:
            raise BovedaModificada(f"Un archivo cambio o desaparecio durante el lote: {rel}. Repite la ejecucion.") from error
        if (stat.st_size, stat.st_mtime_ns) != (expected["size"], expected["mtime_ns"]):
            raise BovedaModificada(f"Un archivo cambio durante el lote: {rel}. Repite la ejecucion cuando termines de editar.")


def ya_sincronizado(migrador, entry, huella, pdf):
    if not entry or entry.get("huella") != huella or not pdf.is_file():
        return False
    if sha_archivo(pdf) != entry.get("pdf_sha256"):
        return False
    expected = entry.get("documento", {})
    if not expected.get("id"):
        return False
    columns = "id,original_name,folder_id,storage_path,extension,pdf_bucket,pdf_storage_path,pdf_size_bytes"
    result = migrador.client.table("documents").select(columns).eq("id", expected["id"]).limit(2).execute()
    rows = result.data or []
    return len(rows) == 1 and all(rows[0].get(k) == expected.get(k) for k in columns.split(","))


def clasificar(error):
    text = str(error).lower()
    if isinstance(error, UnicodeError): return "codificacion"
    if isinstance(error, BovedaModificada): return "boveda_modificada"
    if any(s in text for s in ("adjunto", "imagen", "embedded", "incrustado")): return "adjunto"
    if "yaml" in text or "frontmatter" in text: return "metadatos"
    if "cierra el visor" in text or isinstance(error, PermissionError): return "archivo_bloqueado"
    if "registro:" in text or "xelatex" in text or "pandoc" in text: return "conversion"
    return "sincronizacion"


def guardar_informe(output, registros, total, terminado, general=""):
    counts = dict(Counter(r["estado"] for r in registros))
    report = {"actualizado": datetime.now(timezone.utc).isoformat(), "terminado": terminado,
              "total": total, "procesados": len(registros), "pendientes": total-len(registros),
              "resumen": counts, "error_general": general, "archivos": registros}
    escribir_atomico(output / "informe_migracion.json", json.dumps(report, indent=2, ensure_ascii=False))
    buffer = io.StringIO(newline="")
    fields = ["archivo", "estado", "categoria", "detalle", "registro", "document_id"]
    writer = csv.DictWriter(buffer, fieldnames=fields)
    writer.writeheader()
    for r in registros:
        safe = {}
        for key in fields:
            value = str(r.get(key, ""))
            safe[key] = "'" + value if value.startswith(("=", "+", "-", "@")) else value
        writer.writerow(safe)
    try:
        escribir_atomico(output / "informe_migracion.csv", "\ufeff" + buffer.getvalue())
    except PermissionError:
        print("[AVISO] Cierra el CSV para actualizarlo. El informe JSON si quedo guardado.", flush=True)


def ejecutar_lote(migrador, archivos, forzar=False, versiones=None):
    config = migrador.config
    output = config.output
    output.mkdir(parents=True, exist_ok=True)
    archivos = [Path(p).resolve() for p in archivos]
    if any(not p.is_relative_to(config.vault) for p in archivos):
        raise RuntimeError("Todos los archivos deben estar dentro de la boveda.")
    state_path = output / ".estado_migracion.json"
    registros = []
    with bloqueo(output):
        try:
            state = json.loads(state_path.read_text(encoding="utf-8"))
            if not isinstance(state, dict) or not isinstance(state.get("archivos"), dict):
                raise ValueError("Estado invalido")
        except (FileNotFoundError, ValueError):
            state = {"version": 1, "archivos": {}}
        original_converter, original_validator = migrador.converter, migrador.validar_fuente
        terminado, general, code = False, "", 0
        try:
            guardar_informe(output, registros, len(archivos), False)
            print(f"[LOTE] {len(archivos)} documentos. Preparando la boveda UNA sola vez...", flush=True)
            with tempfile.TemporaryDirectory(prefix="boveda_lote_", dir=output) as tmp:
                inventario = {}
                shadow = preparar_boveda(config.vault, Path(tmp) / "vault", inventario)
                huella = huella_lote(config, inventario, versiones)
                migrador.converter = partial(original_converter, boveda_preparada=shadow)
                migrador.validar_fuente = partial(validar_inventario, config.vault, inventario)
                print(f"[LOTE] Boveda preparada: {len(inventario)} archivos. Iniciando documentos.", flush=True)
                for n, path in enumerate(archivos, 1):
                    rel = path.relative_to(config.vault).as_posix()
                    pdf = ruta_pdf(config.vault, path, output)
                    log = str(pdf.with_suffix(".conversion.log")) if path.suffix.lower() == ".md" else ""
                    record = {"archivo": rel, "estado": "", "categoria": "", "detalle": "",
                              "registro": log, "document_id": ""}
                    print(f"\n[{n}/{len(archivos)}] {rel}", flush=True)
                    try:
                        migrador.validar_fuente()
                        entry = state["archivos"].get(rel)
                        if not forzar and ya_sincronizado(migrador, entry, huella, pdf):
                            record.update(estado="sin_cambios", document_id=entry["documento"]["id"])
                            print("[SIN CAMBIOS] PDF y registro ya sincronizados.", flush=True)
                        else:
                            migrador.ultimo_documento = None
                            doc_id = (migrador.sincronizar_pdf(path) if path.suffix.lower() == ".pdf"
                                      else migrador.sincronizar_nota(path))
                            if doc_id:
                                columns = "id,original_name,folder_id,storage_path,extension,pdf_bucket,pdf_storage_path,pdf_size_bytes".split(",")
                                doc = {k: migrador.ultimo_documento.get(k) for k in columns}
                                state["archivos"][rel] = {"huella": huella, "documento": doc,
                                                          "pdf_sha256": sha_archivo(pdf)}
                                escribir_atomico(state_path, json.dumps(state, ensure_ascii=False, indent=2))
                                record.update(estado="sincronizado", document_id=doc_id)
                            else:
                                record["estado"] = "vacio"
                    except BovedaModificada:
                        raise
                    except Exception as error:
                        detail = str(error).replace(config.key, "[CLAVE OCULTA]")
                        record.update(estado="error", categoria=clasificar(error), detalle=detail)
                        print(f"[ERROR] {rel}: {detail}", flush=True)
                        code = 1
                    registros.append(record)
                    guardar_informe(output, registros, len(archivos), False)
                terminado = True
        except KeyboardInterrupt:
            general = "Interrumpido. Repite el mismo comando para reanudar."
            code = 130
        except Exception as error:
            general = str(error).replace(config.key, "[CLAVE OCULTA]")
            code = 1
        finally:
            migrador.converter, migrador.validar_fuente = original_converter, original_validator
            guardar_informe(output, registros, len(archivos), terminado, general)
        if general: print(f"[LOTE] {general}", flush=True)
        counts = Counter(r["estado"] for r in registros)
        print(f"\nResumen: {counts['sincronizado']} sincronizados; {counts['sin_cambios']} sin cambios; "
              f"{counts['error']} errores; {counts['vacio']} vacios; {len(archivos)-len(registros)} pendientes.", flush=True)
        print(f"Informe: {output / 'informe_migracion.json'}\nCSV: {output / 'informe_migracion.csv'}", flush=True)
        return code
